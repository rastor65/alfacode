import 'package:flutter/material.dart';
import '../../../data/models/user_model.dart';
import '../animals/animal_list_page.dart';
import '../profile/profile_page.dart';
import '../../../routes/app_routes.dart'; // Para la navegación de logout
import '../../widgets/gradient_background.dart'; // Importa el widget de fondo
import '../../../core/constants/app_colors.dart'; // Para colores
import '../../../core/constants/app_text_styles.dart'; // Para estilos de texto

class HomePage extends StatelessWidget {
  final UserModel user;
  const HomePage({required this.user, super.key});

  // Helper method para construir los botones de acción en el grid
  Widget _buildActionButton(BuildContext context, {required IconData icon, required String label, required VoidCallback onTap}) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 48, color: AppColors.primary),
              const SizedBox(height: 10),
              Text(
                label,
                style: AppTextStyles.subtitle1.copyWith(color: AppColors.textDark),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Inicio'), // Título más simple
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              // Implementar lógica de cerrar sesión si es necesario (ej. limpiar datos de sesión)
              Navigator.pushReplacementNamed(context, AppRoutes.login);
            },
            tooltip: 'Cerrar sesión',
          ),
        ],
      ),
      body: GradientBackground( // Usamos el fondo con gradiente
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Tarjeta de Bienvenida al Usuario
              Card(
                elevation: 4,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    children: [
                      CircleAvatar(
                        radius: 40,
                        // Si hay avatarUrl, úsalo, de lo contrario, usa la imagen local de la vaca
                        backgroundImage: user.avatarUrl != null && user.avatarUrl!.isNotEmpty
                            ? NetworkImage(user.avatarUrl!) as ImageProvider
                            : const AssetImage('lib/assets/images/vaca.png'),
                        backgroundColor: AppColors.lightGrey,
                      ),
                      const SizedBox(height: 16),
                      Text(
                        '¡Hola, ${user.nombres?.split(' ').first ?? user.correo.split('@').first}!', // Muestra el primer nombre o parte del correo
                        style: AppTextStyles.headline2.copyWith(color: AppColors.primaryDark),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Bienvenido a tu panel de control ganadero.',
                        style: AppTextStyles.bodyText1.copyWith(color: AppColors.grey),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 30),

              // Sección de Resumen Rápido (Placeholder)
              Card(
                elevation: 4,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Resumen Rápido',
                        style: AppTextStyles.subtitle1.copyWith(color: AppColors.textDark),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        'Aquí podrás ver estadísticas clave y alertas futuras de tus animales.',
                        style: AppTextStyles.bodyText2.copyWith(color: AppColors.grey),
                      ),
                      // Futuro: Aquí se pueden añadir widgets para mostrar el número total de animales,
                      // próximas vacunas, tratamientos pendientes, etc.
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 30),

              // Cuadrícula de Acciones Principales
              GridView.count(
                shrinkWrap: true, // Importante para que GridView no intente ocupar todo el espacio y cause errores de renderizado dentro de SingleChildScrollView
                physics: const NeverScrollableScrollPhysics(), // Deshabilita el scroll propio del GridView
                crossAxisCount: 2, // 2 columnas
                crossAxisSpacing: 20, // Espacio horizontal entre tarjetas
                mainAxisSpacing: 20, // Espacio vertical entre tarjetas
                children: [
                  _buildActionButton(
                    context,
                    icon: Icons.pets,
                    label: 'Mis Animales',
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => AnimalListPage(ownerUsername: user.correo),
                        ),
                      );
                    },
                  ),
                  _buildActionButton(
                    context,
                    icon: Icons.person,
                    label: 'Mi Perfil',
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ProfilePage(userCorreo: user.correo),
                        ),
                      );
                    },
                  ),
                  // Puedes añadir más botones aquí para otras secciones principales
                  // Por ejemplo:
                  // _buildActionButton(
                  //   context,
                  //   icon: Icons.bar_chart,
                  //   label: 'Reportes',
                  //   onTap: () { /* Navegar a página de reportes */ },
                  // ),
                  // _buildActionButton(
                  //   context,
                  //   icon: Icons.settings,
                  //   label: 'Configuración',
                  //   onTap: () { /* Navegar a página de configuración */ },
                  // ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
