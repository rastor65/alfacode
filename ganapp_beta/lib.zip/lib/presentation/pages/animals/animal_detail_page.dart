import 'package:flutter/material.dart';
import '../../../data/models/animal_model.dart';
import '../events/event_list_page.dart';
import '../vacunacion/vacunacion_list_page.dart';
import '../tratamiento/tratamiento_list_page.dart';
import '../alimentacion/alimentacion_list_page.dart';
import '../../widgets/gradient_background.dart'; // Importa el widget de fondo
import '../../../core/constants/app_colors.dart'; // Para colores
import '../../../core/constants/app_text_styles.dart'; // Para estilos de texto

class AnimalDetailPage extends StatelessWidget {
  final AnimalModel animal;

  const AnimalDetailPage({required this.animal, super.key});

  // Helper method para construir los botones de acción
  Widget _buildDetailActionButton(
    BuildContext context, {
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return ElevatedButton.icon(
      icon: Icon(icon),
      label: Text(label),
      onPressed: onTap,
      style: ElevatedButton.styleFrom(
        minimumSize: Size(double.infinity, 50), // Ancho completo
        padding: const EdgeInsets.symmetric(vertical: 15),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(animal.name)),
      body: GradientBackground(
        // Usamos el fondo con gradiente
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Card(
            // Envuelve el contenido principal en un Card
            elevation: 4,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  CircleAvatar(
                    radius: 50,
                    backgroundColor: AppColors.primary.withOpacity(0.1),
                    child: Icon(Icons.pets, size: 60, color: AppColors.primary),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    '${animal.name} (${animal.tipo})',
                    style: AppTextStyles.headline1.copyWith(
                      color: AppColors.primaryDark,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Especie: ${animal.especie}',
                    style: AppTextStyles.subtitle1.copyWith(
                      color: AppColors.grey,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 30),
                  Divider(color: AppColors.lightGrey),
                  const SizedBox(height: 20),
                  _buildDetailActionButton(
                    context,
                    icon: Icons.event,
                    label: 'Ver eventos',
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) =>
                              EventListPage(animalKey: animal.key as int),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 15),
                  _buildDetailActionButton(
                    context,
                    icon: Icons.vaccines,
                    label: 'Ver vacunas',
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) =>
                              VacunacionListPage(animalKey: animal.key as int),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 15),
                  _buildDetailActionButton(
                    context,
                    icon: Icons.healing,
                    label: 'Ver tratamientos',
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) =>
                              TratamientoListPage(animalKey: animal.key as int),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 15),
                  _buildDetailActionButton(
                    context,
                    icon: Icons.restaurant,
                    label: 'Ver alimentación',
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => AlimentacionListPage(
                            animalKey: animal.key as int,
                          ),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
