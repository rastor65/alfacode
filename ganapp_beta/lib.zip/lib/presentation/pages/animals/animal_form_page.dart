import 'package:flutter/material.dart';
import '../../../data/models/animal_model.dart';
import '../../../data/datasources/animal_local_datasource.dart';
import '../../widgets/gradient_background.dart'; // Importa el widget de fondo
import '../../../core/constants/app_colors.dart'; // Para colores
import '../../../core/constants/app_text_styles.dart'; // Para estilos de texto

class AnimalFormPage extends StatefulWidget {
  final String ownerUsername;
  final AnimalModel? animal;

  const AnimalFormPage({super.key, required this.ownerUsername, this.animal});

  @override
  State<AnimalFormPage> createState() => _AnimalFormPageState();
}

class _AnimalFormPageState extends State<AnimalFormPage> {
  final _formKey = GlobalKey<FormState>();
  String name = '';
  String especie = '';
  String tipo = '';
  bool isEdit = false;

  final Map<String, List<String>> especiesTipos = {
    'Vacuno': ['Vaca', 'Toro', 'Ternero'],
    'Ovino': ['Oveja'],
    'Porcino': ['Cerdo'],
    'Caprino': ['Cabra'],
    'Aves de Corral': ['Pollo', 'Pato', 'Pavo'],
  };

  @override
  void initState() {
    super.initState();
    if (widget.animal != null) {
      isEdit = true;
      name = widget.animal!.name;
      especie = widget.animal!.especie;
      tipo = widget.animal!.tipo;
    }
  }

  @override
  Widget build(BuildContext context) {
    List<String> tiposDisponibles = especie.isNotEmpty
        ? especiesTipos[especie] ?? []
        : [];

    return Scaffold(
      appBar: AppBar(title: Text(isEdit ? 'Editar animal' : 'Agregar animal')),
      body: GradientBackground(
        // Usamos el fondo con gradiente
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24.0),
            child: Card(
              // Envuelve el formulario en un Card
              elevation: 4,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text(
                        isEdit
                            ? 'Modificar datos del animal'
                            : 'Registrar nuevo animal',
                        style: AppTextStyles.headline2.copyWith(
                          color: AppColors.primaryDark,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 24),
                      TextFormField(
                        initialValue: name,
                        decoration: InputDecoration(
                          labelText: 'Nombre',
                          prefixIcon: Icon(Icons.abc, color: AppColors.primary),
                        ),
                        onChanged: (val) => name = val,
                        validator: (val) => val!.isEmpty
                            ? 'Ingrese el nombre del animal'
                            : null,
                      ),
                      const SizedBox(height: 16),
                      DropdownButtonFormField<String>(
                        value: especie.isNotEmpty ? especie : null,
                        items: especiesTipos.keys
                            .map(
                              (e) => DropdownMenuItem(value: e, child: Text(e)),
                            )
                            .toList(),
                        onChanged: (val) {
                          setState(() {
                            especie = val ?? '';
                            tipo = '';
                          });
                        },
                        decoration: InputDecoration(
                          labelText: 'Especie',
                          prefixIcon: Icon(
                            Icons.category,
                            color: AppColors.primary,
                          ),
                        ),
                        validator: (val) => val == null || val.isEmpty
                            ? 'Seleccione una especie'
                            : null,
                      ),
                      const SizedBox(height: 16),
                      DropdownButtonFormField<String>(
                        value: tipo.isNotEmpty ? tipo : null,
                        items: tiposDisponibles
                            .map(
                              (t) => DropdownMenuItem(value: t, child: Text(t)),
                            )
                            .toList(),
                        onChanged: (val) => setState(() => tipo = val ?? ''),
                        decoration: InputDecoration(
                          labelText: 'Tipo / Raza',
                          prefixIcon: Icon(
                            Icons.pets_outlined,
                            color: AppColors.primary,
                          ),
                        ),
                        validator: (val) => val == null || val.isEmpty
                            ? 'Seleccione un tipo/raza'
                            : null,
                      ),
                      const SizedBox(height: 24),
                      ElevatedButton(
                        onPressed: () async {
                          if (!_formKey.currentState!.validate()) return;

                          final newAnimal = AnimalModel(
                            name: name,
                            especie: especie,
                            tipo: tipo,
                            ownerUsername: widget.ownerUsername,
                          );

                          final dataSource = AnimalLocalDataSource();
                          if (isEdit && widget.animal != null) {
                            await dataSource.updateAnimal(
                              widget.animal!.key as int,
                              newAnimal,
                            );
                          } else {
                            await dataSource.addAnimal(newAnimal);
                          }

                          Navigator.pop(context, true);
                        },
                        child: Text(isEdit ? 'Guardar cambios' : 'Agregar'),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
