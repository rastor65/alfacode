import 'package:flutter/material.dart';
import '../../../data/datasources/animal_local_datasource.dart';
import '../../../data/models/animal_model.dart';
import 'animal_form_page.dart';
import 'animal_detail_page.dart';
import '../../widgets/gradient_background.dart'; // Importa el widget de fondo
import '../../../core/constants/app_colors.dart'; // Para colores
import '../../../core/constants/app_text_styles.dart'; // Para estilos de texto

class AnimalListPage extends StatefulWidget {
  final String ownerUsername;

  const AnimalListPage({super.key, required this.ownerUsername});

  @override
  State<AnimalListPage> createState() => _AnimalListPageState();
}

class _AnimalListPageState extends State<AnimalListPage> {
  final AnimalLocalDataSource dataSource = AnimalLocalDataSource();
  Map<dynamic, AnimalModel> animalsWithKeys = {};

  @override
  void initState() {
    super.initState();
    _loadAnimals();
  }

  Future<void> _loadAnimals() async {
    animalsWithKeys = await dataSource.getAnimalsWithKeysByOwner(
      widget.ownerUsername,
    );
    setState(() {});
  }

  void _deleteAnimal(dynamic key) async {
    await dataSource.deleteAnimal(key);
    _loadAnimals();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Animal eliminado correctamente'),
        backgroundColor: AppColors.success,
      ),
    );
  }

  void _addOrEditAnimal({AnimalModel? animal, dynamic key}) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
            AnimalFormPage(ownerUsername: widget.ownerUsername, animal: animal),
      ),
    );
    if (result == true) {
      _loadAnimals();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            animal == null
                ? 'Animal agregado correctamente'
                : 'Animal actualizado correctamente',
          ),
          backgroundColor: AppColors.success,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final animals = animalsWithKeys.entries.toList();
    return Scaffold(
      appBar: AppBar(title: Text('Mis animales')),
      body: GradientBackground(
        // Usamos el fondo con gradiente
        child: animals.isEmpty
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(24.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.pets_outlined,
                        size: 80,
                        color: AppColors.grey,
                      ),
                      const SizedBox(height: 20),
                      Text(
                        'No tienes animales registrados.',
                        style: AppTextStyles.headline2.copyWith(
                          color: AppColors.grey,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 10),
                      Text(
                        '¡Agrega tu primer animal para empezar a gestionarlo!',
                        style: AppTextStyles.bodyText1.copyWith(
                          color: AppColors.grey,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              )
            : ListView.separated(
                padding: const EdgeInsets.all(16.0),
                itemCount: animals.length,
                itemBuilder: (context, index) {
                  final key = animals[index].key;
                  final animal = animals[index].value;
                  return Card(
                    // Envuelve cada ListTile en un Card
                    elevation: 2,
                    margin: const EdgeInsets.symmetric(vertical: 8.0),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: ListTile(
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 8,
                      ),
                      leading: CircleAvatar(
                        backgroundColor: AppColors.primary.withOpacity(0.1),
                        child: Icon(Icons.pets, color: AppColors.primary),
                      ),
                      title: Text(
                        '${animal.name} (${animal.tipo})',
                        style: AppTextStyles.subtitle1.copyWith(
                          color: AppColors.textDark,
                        ),
                      ),
                      subtitle: Text(
                        animal.especie,
                        style: AppTextStyles.bodyText2.copyWith(
                          color: AppColors.grey,
                        ),
                      ),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => AnimalDetailPage(animal: animal),
                          ),
                        );
                      },
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: Icon(
                              Icons.edit,
                              color: AppColors.primaryDark,
                            ),
                            onPressed: () =>
                                _addOrEditAnimal(animal: animal, key: key),
                          ),
                          IconButton(
                            icon: Icon(Icons.delete, color: AppColors.error),
                            onPressed: () => _deleteAnimal(key),
                          ),
                        ],
                      ),
                    ),
                  );
                },
                separatorBuilder: (context, index) => const SizedBox(
                  height: 0,
                ), // No necesitamos separador si usamos margin en Card
              ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _addOrEditAnimal(),
        tooltip: 'Agregar animal',
        child: Icon(Icons.add),
      ),
    );
  }
}
