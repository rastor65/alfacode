import 'package:flutter/material.dart';
import '../../../data/datasources/event_local_datasource.dart';
import '../../../data/models/event_model.dart';
import 'event_form_page.dart';
import '../../widgets/gradient_background.dart'; // Importa el widget de fondo
import '../../../core/constants/app_colors.dart'; // Para colores
import '../../../core/constants/app_text_styles.dart'; // Para estilos de texto

class EventListPage extends StatefulWidget {
  final int animalKey;
  const EventListPage({super.key, required this.animalKey});

  @override
  State<EventListPage> createState() => _EventListPageState();
}

class _EventListPageState extends State<EventListPage> {
  final EventLocalDataSource dataSource = EventLocalDataSource();
  Map<dynamic, EventModel> eventsWithKeys = {};

  @override
  void initState() {
    super.initState();
    _loadEvents();
  }

  Future<void> _loadEvents() async {
    eventsWithKeys = await dataSource.getEventsWithKeysForAnimal(
      widget.animalKey,
    );
    setState(() {});
  }

  void _deleteEvent(dynamic key) async {
    await dataSource.deleteEvent(key);
    _loadEvents();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Evento eliminado correctamente'),
        backgroundColor: AppColors.success,
      ),
    );
  }

  void _addOrEditEvent({EventModel? event, dynamic key}) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
            EventFormPage(animalKey: widget.animalKey, event: event),
      ),
    );
    if (result == true) {
      _loadEvents();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            event == null ? 'Evento registrado' : 'Evento actualizado',
          ),
          backgroundColor: AppColors.success,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final events = eventsWithKeys.entries.toList();
    return Scaffold(
      appBar: AppBar(title: Text('Eventos del animal')),
      body: GradientBackground(
        // Usamos el fondo con gradiente
        child: events.isEmpty
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(24.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.event_note, size: 80, color: AppColors.grey),
                      const SizedBox(height: 20),
                      Text(
                        'No hay eventos registrados.',
                        style: AppTextStyles.headline2.copyWith(
                          color: AppColors.grey,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 10),
                      Text(
                        'Agrega un nuevo evento para este animal.',
                        style: AppTextStyles.bodyText1.copyWith(
                          color: AppColors.grey,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              )
            : ListView.separated(
                padding: const EdgeInsets.all(16.0),
                itemCount: events.length,
                itemBuilder: (context, index) {
                  final key = events[index].key;
                  final e = events[index].value;
                  return Card(
                    // Envuelve cada ListTile en un Card
                    elevation: 2,
                    margin: const EdgeInsets.symmetric(vertical: 8.0),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: ListTile(
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 8,
                      ),
                      leading: CircleAvatar(
                        backgroundColor: AppColors.primary.withOpacity(0.1),
                        child: Icon(Icons.event, color: AppColors.primary),
                      ),
                      title: Text(
                        e.tipo,
                        style: AppTextStyles.subtitle1.copyWith(
                          color: AppColors.textDark,
                        ),
                      ),
                      subtitle: Text(
                        'Fecha: ${e.fecha.toLocal().toString().split(' ')[0]}\n${e.descripcion}',
                        style: AppTextStyles.bodyText2.copyWith(
                          color: AppColors.grey,
                        ),
                      ),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: Icon(
                              Icons.edit,
                              color: AppColors.primaryDark,
                            ),
                            onPressed: () =>
                                _addOrEditEvent(event: e, key: key),
                          ),
                          IconButton(
                            icon: Icon(Icons.delete, color: AppColors.error),
                            onPressed: () => _deleteEvent(key),
                          ),
                        ],
                      ),
                    ),
                  );
                },
                separatorBuilder: (context, index) => const SizedBox(height: 0),
              ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _addOrEditEvent(),
        tooltip: 'Registrar evento',
        child: Icon(Icons.add),
      ),
    );
  }
}
