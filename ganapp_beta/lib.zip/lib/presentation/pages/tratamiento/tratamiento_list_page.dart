import 'package:flutter/material.dart';
import '../../../data/datasources/tratamiento_local_datasource.dart';
import '../../../data/models/tratamiento_model.dart';
import 'tratamiento_form_page.dart';
import '../../widgets/gradient_background.dart'; // Importa el widget de fondo
import '../../../core/constants/app_colors.dart'; // Para colores
import '../../../core/constants/app_text_styles.dart'; // Para estilos de texto

class TratamientoListPage extends StatefulWidget {
  final int animalKey;
  const TratamientoListPage({super.key, required this.animalKey});

  @override
  State<TratamientoListPage> createState() => _TratamientoListPageState();
}

class _TratamientoListPageState extends State<TratamientoListPage> {
  final TratamientoLocalDataSource dataSource = TratamientoLocalDataSource();
  Map<dynamic, TratamientoModel> tratamientosWithKeys = {};

  @override
  void initState() {
    super.initState();
    _loadTratamientos();
  }

  Future<void> _loadTratamientos() async {
    tratamientosWithKeys = await dataSource.getTratamientosWithKeysForAnimal(
      widget.animalKey,
    );
    setState(() {});
  }

  void _deleteTratamiento(dynamic key) async {
    await dataSource.deleteTratamiento(key);
    _loadTratamientos();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Tratamiento eliminado correctamente'),
        backgroundColor: AppColors.success,
      ),
    );
  }

  void _addOrEditTratamiento({
    TratamientoModel? tratamiento,
    dynamic key,
  }) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => TratamientoFormPage(
          animalKey: widget.animalKey,
          tratamiento: tratamiento,
        ),
      ),
    );
    if (result == true) {
      _loadTratamientos();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            tratamiento == null
                ? 'Tratamiento registrado'
                : 'Tratamiento actualizado',
          ),
          backgroundColor: AppColors.success,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final tratamientos = tratamientosWithKeys.entries.toList();
    return Scaffold(
      appBar: AppBar(title: Text('Tratamientos del animal')),
      body: GradientBackground(
        // Usamos el fondo con gradiente
        child: tratamientos.isEmpty
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(24.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.healing_outlined,
                        size: 80,
                        color: AppColors.grey,
                      ),
                      const SizedBox(height: 20),
                      Text(
                        'No hay tratamientos registrados.',
                        style: AppTextStyles.headline2.copyWith(
                          color: AppColors.grey,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 10),
                      Text(
                        'Agrega un nuevo tratamiento para este animal.',
                        style: AppTextStyles.bodyText1.copyWith(
                          color: AppColors.grey,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              )
            : ListView.separated(
                padding: const EdgeInsets.all(16.0),
                itemCount: tratamientos.length,
                itemBuilder: (context, index) {
                  final key = tratamientos[index].key;
                  final t = tratamientos[index].value;
                  return Card(
                    // Envuelve cada ListTile en un Card
                    elevation: 2,
                    margin: const EdgeInsets.symmetric(vertical: 8.0),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: ListTile(
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 8,
                      ),
                      leading: CircleAvatar(
                        backgroundColor: AppColors.primary.withOpacity(0.1),
                        child: Icon(Icons.healing, color: AppColors.primary),
                      ),
                      title: Text(
                        t.tipoTratamiento,
                        style: AppTextStyles.subtitle1.copyWith(
                          color: AppColors.textDark,
                        ),
                      ),
                      subtitle: Text(
                        'Medicamento: ${t.medicamento}\nFecha: ${t.fechaAplicacion.toLocal().toString().split(' ')[0]}\n${t.observaciones}',
                        style: AppTextStyles.bodyText2.copyWith(
                          color: AppColors.grey,
                        ),
                      ),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: Icon(
                              Icons.edit,
                              color: AppColors.primaryDark,
                            ),
                            onPressed: () =>
                                _addOrEditTratamiento(tratamiento: t, key: key),
                          ),
                          IconButton(
                            icon: Icon(Icons.delete, color: AppColors.error),
                            onPressed: () => _deleteTratamiento(key),
                          ),
                        ],
                      ),
                    ),
                  );
                },
                separatorBuilder: (context, index) => const SizedBox(height: 0),
              ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _addOrEditTratamiento(),
        tooltip: 'Registrar tratamiento',
        child: Icon(Icons.add),
      ),
    );
  }
}
