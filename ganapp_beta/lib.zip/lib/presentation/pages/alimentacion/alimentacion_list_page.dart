import 'package:flutter/material.dart';
import '../../../data/datasources/alimentacion_local_datasource.dart';
import '../../../data/models/alimentacion_model.dart';
import 'alimentacion_form_page.dart';
import '../../widgets/gradient_background.dart'; // Importa el widget de fondo
import '../../../core/constants/app_colors.dart'; // Para colores
import '../../../core/constants/app_text_styles.dart'; // Para estilos de texto

class AlimentacionListPage extends StatefulWidget {
  final int animalKey;
  const AlimentacionListPage({super.key, required this.animalKey});

  @override
  State<AlimentacionListPage> createState() => _AlimentacionListPageState();
}

class _AlimentacionListPageState extends State<AlimentacionListPage> {
  final AlimentacionLocalDataSource dataSource = AlimentacionLocalDataSource();
  Map<dynamic, AlimentacionModel> alimentacionesWithKeys = {};

  @override
  void initState() {
    super.initState();
    _loadAlimentaciones();
  }

  Future<void> _loadAlimentaciones() async {
    alimentacionesWithKeys = await dataSource
        .getAlimentacionesWithKeysForAnimal(widget.animalKey);
    setState(() {});
  }

  void _deleteAlimentacion(dynamic key) async {
    await dataSource.deleteAlimentacion(key);
    _loadAlimentaciones();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Registro de alimentación eliminado'),
        backgroundColor: AppColors.success,
      ),
    );
  }

  void _addOrEditAlimentacion({
    AlimentacionModel? alimentacion,
    dynamic key,
  }) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => AlimentacionFormPage(
          animalKey: widget.animalKey,
          alimentacion: alimentacion,
        ),
      ),
    );
    if (result == true) {
      _loadAlimentaciones();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            alimentacion == null
                ? 'Alimentación registrada'
                : 'Alimentación actualizada',
          ),
          backgroundColor: AppColors.success,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final alimentaciones = alimentacionesWithKeys.entries.toList();
    return Scaffold(
      appBar: AppBar(title: Text('Alimentación del animal')),
      body: GradientBackground(
        // Usamos el fondo con gradiente
        child: alimentaciones.isEmpty
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(24.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.restaurant_menu,
                        size: 80,
                        color: AppColors.grey,
                      ),
                      const SizedBox(height: 20),
                      Text(
                        'No hay registros de alimentación.',
                        style: AppTextStyles.headline2.copyWith(
                          color: AppColors.grey,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 10),
                      Text(
                        'Agrega un nuevo registro de alimentación para este animal.',
                        style: AppTextStyles.bodyText1.copyWith(
                          color: AppColors.grey,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              )
            : ListView.separated(
                padding: const EdgeInsets.all(16.0),
                itemCount: alimentaciones.length,
                itemBuilder: (context, index) {
                  final key = alimentaciones[index].key;
                  final a = alimentaciones[index].value;
                  return Card(
                    // Envuelve cada ListTile en un Card
                    elevation: 2,
                    margin: const EdgeInsets.symmetric(vertical: 8.0),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: ListTile(
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 8,
                      ),
                      leading: CircleAvatar(
                        backgroundColor: AppColors.primary.withOpacity(0.1),
                        child: Icon(Icons.restaurant, color: AppColors.primary),
                      ),
                      title: Text(
                        a.tipoAlimento,
                        style: AppTextStyles.subtitle1.copyWith(
                          color: AppColors.textDark,
                        ),
                      ),
                      subtitle: Text(
                        'Cantidad: ${a.cantidad} kg\nFecha: ${a.fecha.toLocal().toString().split(' ')[0]}\n${a.observaciones}',
                        style: AppTextStyles.bodyText2.copyWith(
                          color: AppColors.grey,
                        ),
                      ),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: Icon(
                              Icons.edit,
                              color: AppColors.primaryDark,
                            ),
                            onPressed: () => _addOrEditAlimentacion(
                              alimentacion: a,
                              key: key,
                            ),
                          ),
                          IconButton(
                            icon: Icon(Icons.delete, color: AppColors.error),
                            onPressed: () => _deleteAlimentacion(key),
                          ),
                        ],
                      ),
                    ),
                  );
                },
                separatorBuilder: (context, index) => const SizedBox(height: 0),
              ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _addOrEditAlimentacion(),
        tooltip: 'Registrar alimentación',
        child: Icon(Icons.add),
      ),
    );
  }
}
