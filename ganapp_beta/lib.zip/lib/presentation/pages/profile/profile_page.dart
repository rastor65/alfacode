import 'package:flutter/material.dart';
import '../../../data/models/user_model.dart';
import '../../../data/datasources/user_local_datasource.dart';
import '../../../data/datasources/rol_local_datasource.dart';
import '../../../data/datasources/recurso_local_datasource.dart';
import '../../../data/datasources/usuario_rol_local_datasource.dart';
import '../../../data/datasources/rol_recurso_local_datasource.dart';
import '../../../data/repositories/user_repository.dart';
import '../../widgets/gradient_background.dart'; // Importa el widget de fondo
import '../../../core/constants/app_colors.dart'; // Para colores
import '../../../core/constants/app_text_styles.dart'; // Para estilos de texto

class ProfilePage extends StatefulWidget {
  final String userCorreo;
  const ProfilePage({required this.userCorreo, super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final _formKey = GlobalKey<FormState>();
  String? nombres;
  String? apellidos;
  String? identificacion;
  String? celular;
  String? comunidad;
  String? avatarUrl;
  bool isLoading = true;
  UserModel? user;

  late UserRepository _userRepository;

  @override
  void initState() {
    super.initState();
    _userRepository = UserRepository(
      userLocalDataSource: UserLocalDataSource(),
      rolLocalDataSource: RolLocalDataSource(),
      recursoLocalDataSource: RecursoLocalDataSource(),
      usuarioRolLocalDataSource: UsuarioRolLocalDataSource(),
      rolRecursoLocalDataSource: RolRecursoLocalDataSource(),
    );
    _loadUser();
  }

  Future<void> _loadUser() async {
    user = await _userRepository.userLocalDataSource.getUserByCorreo(widget.userCorreo);
    setState(() {
      nombres = user?.nombres ?? '';
      apellidos = user?.apellidos ?? '';
      identificacion = user?.identificacion ?? '';
      celular = user?.celular ?? '';
      comunidad = user?.comunidad ?? '';
      avatarUrl = user?.avatarUrl ?? '';
      isLoading = false;
    });
  }

  void _saveProfile() async {
    if (!_formKey.currentState!.validate() || user == null) return;
    setState(() => isLoading = true);

    user!
      ..nombres = nombres
      ..apellidos = apellidos
      ..identificacion = identificacion
      ..celular = celular
      ..comunidad = comunidad
      ..avatarUrl = avatarUrl;

    await _userRepository.updateUser(user!);

    setState(() => isLoading = false);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Perfil actualizado correctamente'), backgroundColor: AppColors.success),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) return Scaffold(body: Center(child: CircularProgressIndicator(color: AppColors.primary)));

    return Scaffold(
      appBar: AppBar(title: Text('Mi perfil')),
      body: GradientBackground( // Usamos el fondo con gradiente
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24.0),
            child: Card( // Envuelve el formulario en un Card
              elevation: 4,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      CircleAvatar(
                        radius: 50,
                        backgroundImage: avatarUrl != null && avatarUrl!.isNotEmpty
                            ? NetworkImage(avatarUrl!) as ImageProvider
                            : const AssetImage('lib/assets/images/vaca.png'), // Placeholder
                        backgroundColor: AppColors.lightGrey,
                      ),
                      const SizedBox(height: 20),
                      Text(
                        'Editar mi perfil',
                        style: AppTextStyles.headline2.copyWith(color: AppColors.primaryDark),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 24),
                      TextFormField(
                        initialValue: nombres,
                        decoration: InputDecoration(
                          labelText: 'Nombres',
                          prefixIcon: Icon(Icons.person_outline, color: AppColors.primary),
                        ),
                        onChanged: (val) => nombres = val,
                        validator: (val) => val!.isEmpty ? 'Ingrese sus nombres' : null,
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        initialValue: apellidos,
                        decoration: InputDecoration(
                          labelText: 'Apellidos',
                          prefixIcon: Icon(Icons.person_outline, color: AppColors.primary),
                        ),
                        onChanged: (val) => apellidos = val,
                        validator: (val) => val!.isEmpty ? 'Ingrese sus apellidos' : null,
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        initialValue: identificacion,
                        decoration: InputDecoration(
                          labelText: 'Identificación',
                          prefixIcon: Icon(Icons.credit_card, color: AppColors.primary),
                        ),
                        keyboardType: TextInputType.number,
                        onChanged: (val) => identificacion = val,
                        validator: (val) => val!.isEmpty ? 'Ingrese su número de identificación' : null,
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        initialValue: celular,
                        decoration: InputDecoration(
                          labelText: 'Celular',
                          prefixIcon: Icon(Icons.phone, color: AppColors.primary),
                        ),
                        keyboardType: TextInputType.phone,
                        onChanged: (val) => celular = val,
                        validator: (val) => val!.isEmpty ? 'Ingrese su número de celular' : null,
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        initialValue: comunidad,
                        decoration: InputDecoration(
                          labelText: 'Comunidad',
                          prefixIcon: Icon(Icons.location_on_outlined, color: AppColors.primary),
                        ),
                        onChanged: (val) => comunidad = val,
                        validator: (val) => val!.isEmpty ? 'Ingrese su comunidad' : null,
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        initialValue: avatarUrl,
                        decoration: InputDecoration(
                          labelText: 'URL de Avatar (Opcional)',
                          prefixIcon: Icon(Icons.image, color: AppColors.primary),
                        ),
                        onChanged: (val) => avatarUrl = val,
                      ),
                      const SizedBox(height: 24),
                      ElevatedButton(
                        onPressed: _saveProfile,
                        child: Text('Guardar cambios'),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
