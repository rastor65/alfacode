import 'package:flutter/material.dart';
import '../../../data/datasources/vacunacion_local_datasource.dart';
import '../../../data/models/vacunacion_model.dart';
import 'vacunacion_form_page.dart';
import '../../widgets/gradient_background.dart'; // Importa el widget de fondo
import '../../../core/constants/app_colors.dart'; // Para colores
import '../../../core/constants/app_text_styles.dart'; // Para estilos de texto

class VacunacionListPage extends StatefulWidget {
  final int animalKey;
  const VacunacionListPage({super.key, required this.animalKey});

  @override
  State<VacunacionListPage> createState() => _VacunacionListPageState();
}

class _VacunacionListPageState extends State<VacunacionListPage> {
  final VacunacionLocalDataSource dataSource = VacunacionLocalDataSource();
  Map<dynamic, VacunacionModel> vacunacionesWithKeys = {};

  @override
  void initState() {
    super.initState();
    _loadVacunaciones();
  }

  Future<void> _loadVacunaciones() async {
    vacunacionesWithKeys = await dataSource.getVacunacionesWithKeysForAnimal(
      widget.animalKey,
    );
    setState(() {});
  }

  void _deleteVacunacion(dynamic key) async {
    await dataSource.deleteVacunacion(key);
    _loadVacunaciones();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Vacuna eliminada correctamente'),
        backgroundColor: AppColors.success,
      ),
    );
  }

  void _addOrEditVacunacion({VacunacionModel? vacunacion, dynamic key}) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => VacunacionFormPage(
          animalKey: widget.animalKey,
          vacunacion: vacunacion,
        ),
      ),
    );
    if (result == true) {
      _loadVacunaciones();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            vacunacion == null ? 'Vacuna registrada' : 'Vacuna actualizada',
          ),
          backgroundColor: AppColors.success,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final vacunaciones = vacunacionesWithKeys.entries.toList();
    return Scaffold(
      appBar: AppBar(title: Text('Vacunación del animal')),
      body: GradientBackground(
        // Usamos el fondo con gradiente
        child: vacunaciones.isEmpty
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(24.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.vaccines_outlined,
                        size: 80,
                        color: AppColors.grey,
                      ),
                      const SizedBox(height: 20),
                      Text(
                        'No hay vacunas registradas.',
                        style: AppTextStyles.headline2.copyWith(
                          color: AppColors.grey,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 10),
                      Text(
                        'Agrega una nueva vacuna para este animal.',
                        style: AppTextStyles.bodyText1.copyWith(
                          color: AppColors.grey,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              )
            : ListView.separated(
                padding: const EdgeInsets.all(16.0),
                itemCount: vacunaciones.length,
                itemBuilder: (context, index) {
                  final key = vacunaciones[index].key;
                  final vac = vacunaciones[index].value;
                  return Card(
                    // Envuelve cada ListTile en un Card
                    elevation: 2,
                    margin: const EdgeInsets.symmetric(vertical: 8.0),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: ListTile(
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 8,
                      ),
                      leading: CircleAvatar(
                        backgroundColor: AppColors.primary.withOpacity(0.1),
                        child: Icon(Icons.vaccines, color: AppColors.primary),
                      ),
                      title: Text(
                        vac.nombreVacuna,
                        style: AppTextStyles.subtitle1.copyWith(
                          color: AppColors.textDark,
                        ),
                      ),
                      subtitle: Text(
                        'Fecha: ${vac.fechaAplicacion.toLocal().toString().split(' ')[0]}\n${vac.observaciones}',
                        style: AppTextStyles.bodyText2.copyWith(
                          color: AppColors.grey,
                        ),
                      ),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: Icon(
                              Icons.edit,
                              color: AppColors.primaryDark,
                            ),
                            onPressed: () =>
                                _addOrEditVacunacion(vacunacion: vac, key: key),
                          ),
                          IconButton(
                            icon: Icon(Icons.delete, color: AppColors.error),
                            onPressed: () => _deleteVacunacion(key),
                          ),
                        ],
                      ),
                    ),
                  );
                },
                separatorBuilder: (context, index) => const SizedBox(height: 0),
              ),
      ), // Usamos el fondo con gradiente
      floatingActionButton: FloatingActionButton(
        onPressed: () => _addOrEditVacunacion(),
        tooltip: 'Registrar vacuna',
        child: Icon(Icons.add),
      ),
    );
  }
}
