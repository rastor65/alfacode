import 'package:flutter/material.dart';
import '../presentation/pages/splash/splash_page.dart';
import '../presentation/pages/login/login_page.dart';
import '../presentation/pages/register/register_page.dart';

class AppRoutes {
  static const String splash = '/';
  static const String login = '/login';
  static const String register = '/register';
  static const String home = '/home';

  static Map<String, WidgetBuilder> routes = {
    splash: (context) => SplashPage(),
    login: (context) => LoginPage(),
    register: (context) => RegisterPage(),
  };
}

