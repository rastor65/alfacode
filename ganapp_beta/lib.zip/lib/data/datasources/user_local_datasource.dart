import 'package:hive/hive.dart';
import '../models/user_model.dart';

class UserLocalDataSource {
  static const _boxName = 'users';

  Future<void> addUser(UserModel user) async {
    final box = await Hive.openBox<UserModel>(_boxName);
    await box.put(user.id, user);
  }

  Future<UserModel?> getUserById(int id) async {
    final box = await Hive.openBox<UserModel>(_boxName);
    return box.get(id);
  }

  Future<UserModel?> getUserByCorreo(String correo) async {
    final box = await Hive.openBox<UserModel>(_boxName);
    try {
      return box.values.firstWhere((u) => u.correo == correo);
    } catch (_) {
      return null;
    }
  }

  Future<List<UserModel>> getAllUsers() async {
    final box = await Hive.openBox<UserModel>(_boxName);
    return box.values.toList();
  }

  Future<void> updateUser(UserModel user) async {
    final box = await Hive.openBox<UserModel>(_boxName);
    await box.put(user.id, user);
  }
}
