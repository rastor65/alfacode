import 'package:hive/hive.dart';
import '../models/animal_model.dart';

class AnimalLocalDataSource {
  static const _boxName = 'animals';

  Future<void> addAnimal(AnimalModel animal) async {
    final box = await Hive.openBox<AnimalModel>(_boxName);
    await box.add(animal);
  }

  Future<List<AnimalModel>> getAnimalsByOwner(String ownerUsername) async {
    final box = await Hive.openBox<AnimalModel>(_boxName);
    return box.values.where((a) => a.ownerUsername == ownerUsername).toList();
  }

  Future<void> deleteAnimal(int key) async {
    final box = await Hive.openBox<AnimalModel>(_boxName);
    await box.delete(key);
  }

  Future<void> updateAnimal(int key, AnimalModel animal) async {
    final box = await Hive.openBox<AnimalModel>(_boxName);
    await box.put(key, animal);
  }

  Future<Map<dynamic, AnimalModel>> getAnimalsWithKeysByOwner(String ownerUsername) async {
    final box = await Hive.openBox<AnimalModel>(_boxName);
    final allAnimals = box.toMap();
    return Map.fromEntries(
      allAnimals.entries.where((e) => e.value.ownerUsername == ownerUsername),
    );
  }
}
