import 'package:hive/hive.dart';

part 'animal_model.g.dart';

@HiveType(typeId: 1)
class AnimalModel extends HiveObject {
  @HiveField(0)
  final String name;
  @HiveField(1)
  final String especie; // Vacuno, Ovino, Porcino, Caprino, Aves de Corral
  @HiveField(2)
  final String tipo;    // Vaca, Toro, Ternero, Oveja, Cerdo, Cabra, Pollo, Pato, Pavo
  @HiveField(3)
  final String ownerUsername;

  AnimalModel({
    required this.name,
    required this.especie,
    required this.tipo,
    required this.ownerUsername,
  });
}
